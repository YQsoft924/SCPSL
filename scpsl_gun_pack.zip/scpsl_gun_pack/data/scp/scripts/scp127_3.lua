local M = {}

M.shootCounter = 0
M.timerTaskId = nil
M.reloadTaskId = nil

function M.shoot(api)
    if api:getAmmoAmount() > 0 then
        api:shootOnce(api:isShootingNeedConsumeAmmo())
        
        M.shootCounter = M.shootCounter + 1
        local myShootId = M.shootCounter
        
        -- 清理所有旧任务
        if M.timerTaskId then
            api:cancelAsyncTask(M.timerTaskId)
            M.timerTaskId = nil
        end
        if M.reloadTaskId then
            api:cancelAsyncTask(M.reloadTaskId)
            M.reloadTaskId = nil
        end
        
        -- 使用计数器实现5秒延迟
        local countdown = 0
        M.timerTaskId = api:safeAsyncTask(
            function()
                -- 检查是否有新射击
                if M.shootCounter ~= myShootId then
                    return false
                end
                
                countdown = countdown + 100
                
                -- 还没到5秒，继续等待
                if countdown < 1000 then
                    return true
                end
                
                -- 5秒到了，停止计时器，开始补弹
                M.timerTaskId = nil
                M.reloadTaskId = api:safeAsyncTask(
                    function()
                        if M.shootCounter ~= myShootId then
                            return false
                        end
                        
                        if api:getMaxAmmoCount() == api:getAmmoAmount() then
                            return false
                        end
                        
                        api:putAmmoInMagazine(1)
                        return true
                    end,
                    0,   -- 立即开始
                    166, -- 每500ms一发
                    api:getMaxAmmoCount() - api:getAmmoAmount()
                )
                
                return false
            end,
            0,   -- 立即开始计时
            100, -- 每100ms检查一次
            -1   -- 无限次数直到条件满足
        )
    end
end

return M
